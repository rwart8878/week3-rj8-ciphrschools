import React from 'react'

function ChildComponent(name) {
  return (
    <div>ChildComponent{name}</div>
  )
}

export default ChildComponent